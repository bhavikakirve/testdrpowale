Author: CodexWorld
Author URL: http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/add-remove-input-fields-dynamically-using-jquery/

============ Instruction ============
Move the "add_more_fields_using_jquery/" folder to the localhost => Open the "index.php" file at the browser => test functioanlity.


============ May I Help You ===========
If you have any query about this script, please feel free to contact us at contact@codexworld.com. We will reply your query soon.